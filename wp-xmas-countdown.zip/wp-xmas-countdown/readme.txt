=== Christmas Countdown ===
Contributors: justinrains
Tags: countdown, christmas, xmas
Requires at least: 4.5
Tested up to: 4.8
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin allows the admin to select add a widget to their sidebar that shows the number of days left to Christmas of the current year.

== Description ==

This plugin adds a countdown widget to the WordPress sidebar area.

For more information visit:

[WP Christmas Countdown Widget](http://portalplanet.net/wordpress/wordpress-themes-plugins/support-ribbon-wordpress-plugin/)

== Installation ==

1. Upload the `wp-xmas-countdown` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to the settings (Admin > Settings > Ribbon Manager)
4. Select the ribbon you would like to be displayed and click save.
5. Go to your site and the ribbon will be displayed at the bottom left corner of your pages/posts.

== Screenshots ==

1. Site showing the ribbon being displayed.
2. Ribbon settings page.

= Need a plugin developed? =
Feel free to [contact the author](http://justinrains.com). I'm available for work. Thanks!
